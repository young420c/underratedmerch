<?php
// Heading
$_['heading_title']    = 'Free Shipping';

// Text
$_['text_description'] = 'Free Shipping';