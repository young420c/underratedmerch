<?php
// Heading
$_['heading_title'] = 'Information';

// Text
$_['text_contact']  = 'Contact Us';
$_['text_sitemap']  = 'Site Map';